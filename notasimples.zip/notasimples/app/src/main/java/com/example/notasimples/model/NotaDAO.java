package com.example.notasimples.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class NotaDAO {

SQLiteDatabase db;
 public NotaDAO(Context context){
db = context.openOrCreateDatabase("db", 0, null);
    db.execSQL("CREATE TABLE IF NOT EXISTS itens (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
             "titulo VARCHAR," +
            " texto VARCHAR );" +
            "");
 }








    public void inserirNota(Nota nota){

    }

    public  void excluirNota(Nota nota){
    }


    public Nota getNota(int id){
        return null;
    }



    public ArrayList<Nota> listarNotas(){
        return null;
    }
}
