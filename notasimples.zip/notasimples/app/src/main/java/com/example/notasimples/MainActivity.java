package com.example.notasimples;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase sqlbd;

    EditText editText;
    Button btnAdicionarItem;
    ListView listView;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        btnAdicionarItem = findViewById(R.id.btnAdicionarItem);
        editText = findViewById(R.id.editText);

        sqlbd = openOrCreateDatabase("itens", MODE_PRIVATE, null);
        sqlbd.execSQL("CREATE TABLE IF NOT EXISTS itens (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_lista VARCHAR );");
        exibirListaDeItens();
    }
    @SuppressLint("Range")
    public void adicionarItemNaLista(View view) {
        String item = editText.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("item_lista", item);
        sqlbd.insert("itens", null, cv);

        exibirListaDeItens();
    }
    @SuppressLint("Range")
    public void exibirListaDeItens(){

        Cursor meuCursor = sqlbd.rawQuery("SELECT item_lista FROM itens", null);
        ArrayList<String> listaDeItens = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1, listaDeItens
        );
        listView.setAdapter(arrayAdapter);
        meuCursor.moveToFirst();

        while (!meuCursor.isAfterLast()){
            listaDeItens.add(meuCursor.getString(meuCursor.getColumnIndex("item_lista")));
            meuCursor.moveToNext();
        }

    }
}