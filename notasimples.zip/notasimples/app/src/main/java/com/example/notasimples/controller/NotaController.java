package com.example.notasimples.controller;

import android.content.Context;

import com.example.notasimples.model.Nota;
import com.example.notasimples.model.NotaDAO;

import java.util.ArrayList;

public class NotaController {
    NotaDAO nDAO;
public NotaController(Context c){

    nDAO = new NotaDAO(c);



}

    public void cadastraNota(Nota n){
    if(n.getTitulo().length()>3){
        nDAO.inserirNota(n);

    }
    }


    public Nota getNota(int idNota){
        return nDAO.getNota(idNota);
    }


    public void excluirNota(Nota nota){
     nDAO.excluirNota(nota);
    }




    public ArrayList<Nota> listarNotas(){
        return nDAO.listarNotas();
    }



public  ArrayList<String> recuperaTitulosNotas(){

    ArrayList<String> tituloNotas = new ArrayList<>();
    for(Nota n: this.listarNotas()){
        tituloNotas.add(n.getTitulo());


    }

    return tituloNotas;
}
}
